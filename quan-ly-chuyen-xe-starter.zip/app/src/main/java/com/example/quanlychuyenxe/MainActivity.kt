package com.example.quanlychuyenxe

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    // Simple in-memory totals (no DB) for starter
    private var totalGross = 0L
    private var totalExpense = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etThu = findViewById<EditText>(R.id.etThu)
        val etXang = findViewById<EditText>(R.id.etXang)
        val etDo = findViewById<EditText>(R.id.etDo)
        val etMuon = findViewById<EditText>(R.id.etMuon)

        val btnLuu = findViewById<Button>(R.id.btnLuu)
        val tvGross = findViewById<TextView>(R.id.tvGross)
        val tvExpense = findViewById<TextView>(R.id.tvExpense)
        val tvNet = findViewById<TextView>(R.id.tvNet)

        fun fmt(v: Long): String {
            val nf = NumberFormat.getInstance(Locale("vi","VN"))
            return nf.format(v) + " đ"
        }

        fun refresh() {
            tvGross.text = fmt(totalGross)
            tvExpense.text = fmt(totalExpense)
            tvNet.text = fmt(totalGross - totalExpense)
        }

        btnLuu.setOnClickListener {
            val thu = etThu.text.toString().replace("\D".toRegex(), "").let { if (it.isEmpty()) 0L else it.toLong() }
            val xang = etXang.text.toString().replace("\D".toRegex(), "").let { if (it.isEmpty()) 0L else it.toLong() }
            val dochi = etDo.text.toString().replace("\D".toRegex(), "").let { if (it.isEmpty()) 0L else it.toLong() }
            val muon = etMuon.text.toString().replace("\D".toRegex(), "").let { if (it.isEmpty()) 0L else it.toLong() }

            totalGross += thu
            totalExpense += (xang + dochi + muon)

            // clear inputs
            etThu.text.clear()
            etXang.text.clear()
            etDo.text.clear()
            etMuon.text.clear()

            refresh()
        }

        // initial
        refresh()
    }
}
