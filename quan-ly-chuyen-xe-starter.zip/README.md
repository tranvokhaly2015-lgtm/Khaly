Quản Lý Chuyến Xe - Starter Android Project (Kotlin)
----------------------------------------------------
Nội dung:
- MainActivity.kt: logic hiển thị tổng thu/chi, thêm chuyến.
- layout/activity_main.xml: layout đơn giản.
- AndroidManifest.xml, build.gradle files.

Hướng dẫn build:
1. Tải Android Studio.
2. Mở 'Open an existing project' và chọn thư mục này.
3. Android Studio sẽ tự tải Gradle/SDK nếu thiếu.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK sẽ có trong app/build/outputs/apk/debug/app-debug.apk

Nếu cần mình có thể hướng dẫn chi tiết hơn (sign release, add DB, export).
